# mypackage
This library was created as an example of how to publish your own Python package.

## Building this package locally
`python setup.py sdist`

## Installing this package from GitHub
`pip install git+http://github.com/James-Leslie/example-python-package.git`
